<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
    public function index()
    {
        $this->load->view('index');
    }

    public function tentangkami()
    {
        $this->load->view('tentangkami');
    }

    public function ebook()
    {
        $this->load->view('ebook');
    }

    public function anggota()
    {
        $this->load->view('anggota');
    }
    public function pengumuman()
    {
        $this->load->view('pengumuman');
    }
    public function panduan()
    {
        $this->load->view('panduan');
    }
    public function Kontak()
    {
        $this->load->view('kontak');
    }
}
