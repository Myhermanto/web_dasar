<html>

<head>
    <title>Halaman Biodata Saya</title>
</head>

<body>
    <h1>Ini Halaman Biodata Saya</h1>
    <p>Nim : 12345 <br>
        Nama : John Doe <br>
        Kelas : 12A <br>
        Alamat : Jalan Merdeka No.1 <br>
        Hobi : Membaca Buku
    </p>
</body>

</html>